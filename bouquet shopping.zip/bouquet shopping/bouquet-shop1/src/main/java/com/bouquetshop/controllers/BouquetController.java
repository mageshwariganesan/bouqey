
package com.bouquetshop.controllers;

import com.bouquetshop.models.Bouquet;
import com.bouquetshop.services.BouquetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bouquets")
@CrossOrigin(origins = "*")
public class BouquetController {
    @Autowired
    private BouquetService bouquetService;

    @GetMapping
    public List<Bouquet> getAllBouquets() {
        return bouquetService.getAllBouquets();
    }

    @GetMapping("/{id}")
    public Bouquet getBouquet(@PathVariable Long id) {
        return bouquetService.getBouquetById(id);
    }

    @PostMapping
    public Bouquet addBouquet(@RequestBody Bouquet bouquet) {
        return bouquetService.addBouquet(bouquet);
    }

    @DeleteMapping("/{id}")
    public void deleteBouquet(@PathVariable Long id) {
        bouquetService.deleteBouquet(id);
    }
}
