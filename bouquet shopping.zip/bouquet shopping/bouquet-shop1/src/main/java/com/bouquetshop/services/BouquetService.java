
package com.bouquetshop.services;

import com.bouquetshop.models.Bouquet;
import com.bouquetshop.repositories.BouquetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BouquetService {
    @Autowired
    private BouquetRepository bouquetRepository;

    public List<Bouquet> getAllBouquets() {
        return bouquetRepository.findAll();
    }

    public Bouquet getBouquetById(Long id) {
        return bouquetRepository.findById(id).orElse(null);
    }

    public Bouquet addBouquet(Bouquet bouquet) {
        return bouquetRepository.save(bouquet);
    }

    public void deleteBouquet(Long id) {
        bouquetRepository.deleteById(id);
    }
}
